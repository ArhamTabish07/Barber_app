import 'package:flutter/material.dart';

class ColorConstant {
  static Color backgroundColor = Color(0xff2b1615);
}
